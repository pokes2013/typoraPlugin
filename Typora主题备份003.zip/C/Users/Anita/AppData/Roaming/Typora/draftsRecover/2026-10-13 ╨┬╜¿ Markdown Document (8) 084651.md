

# ✅ Vue3 学习路线（专门适配你：Django 后端，做后台管理 UI）

> 直接学 **Vue3 + Vite + ，不要学 Vue2；后台 UI 组件库用 \**Element Plus\**，最适合做 ERP/HR/ 巡检管理页面。 前提基础：简单的 HTML、CSS、JavaScript（基础 JS 就行，不用精通）**

## 第 0 步：准备开发环境（先装好）

1. **Node.js（LTS 长期支持版）**，自带 npm，用来创建项目、安装依赖、打包
2. **VS Code**，装插件：Volar（Vue 语法高亮）

```
# 验证是否安装成功，cmd执行
node -v
npm -v
# 创建Vue3项目（Vite，官方推荐）
npm create vite@latest my-vue-ui -- --template vue
cd my-vue-ui
npm install
npm run serve
```

执行完浏览器打开 `http://localhost:5173`，项目跑起来。

## 阶段 1：Vue3 基础（核心，大概 3～5 天）

看**Vue 官方中文文档**（最权威），重点掌握这些：

1. 模板语法：插值 `{{}}`、`v-model`双向绑定、`v-for`循环、`v-if/v-show`、事件`@click`
2. 响应式：`ref`、`reactive`（组合式 API setup 语法糖，**只学这个**）
3. 计算属性 computed、监听器 watch
4. **组件**：单文件组件 `.vue`（template /script/style），父子组件传值 props、emit

> 目标：能独立写页面，表单、列表、弹窗，用 mock 假数据渲染界面

## 阶段 2：配套全家桶（做后台必备，2～3 天）

1. **Element Plus** ✅（重点！省大量写 UI 的时间） 现成表格、分页、表单、弹窗、菜单、搜索框，后台管理首选

   ```
   npm install element-plus
   ```

2. **Vue Router**：页面路由，菜单跳转（就是你前面关心的 history 模式，打包部署刷新 404 就是它）

   ```
   npm install vue-router@4
   ```

3. **Axios**：前端请求 Django 后端 API（GET/POST 提交数据）

   ```
   npm install axios
   ```

4. Pinia（可选）：简单项目可以暂时不学；复杂多页面共享数据再用

## 阶段 3：实战（重点！你的目标：先写 UI，mock 假数据）

👉 就按你计划的流程：

1. 用 Element Plus 搭建布局：侧边菜单、顶部导航、主内容区
2. 写页面：员工列表、新增表单、搜索、分页，**先用写死的 JSON 模拟数据**，不用连 Django
3. 页面交互：新增弹窗、删除确认、表单校验
4. 本地 `npm run build`，生成 dist 静态包，测试打包

## 阶段 4：前后联调（对接 Django，2 天）

1. Axios 把假数据替换成请求 Django `/api/xxx`
2. Django 安装`django-cors-headers`解决本地开发跨域
3. 调试：列表加载、提交保存、删除

## 阶段 5：打包 + 部署（前面聊过）

```
npm run build
```

产出 dist 文件夹，Nginx 托管前端，api 反向代理 Django。

# 📚 学习资源推荐

1. **首选：Vue 官方中文文档** https://cn.vuejs.org/guide/introduction.html（免费，最准）
2. Element Plus 官网：直接复制组件代码，拿来改一改就能用 https://element-plus.org/zh-CN/
3. B 站视频：Vue3+Element Plus 后台管理实战，适合跟着敲代码

# 📌 避坑提醒（对你很关键）

1. 不要上来就学 TS（TypeScript），小项目先写原生 JS，降低门槛
2. 优先做页面 UI，**前端只做展示，权限、数据校验核心逻辑放 Django 后端**
3. 开发阶段：`npm run dev` 本地预览；上线**必须 build 打包 dist**，服务器不需要 node
4. 小项目 Pinia 可以跳过，等后面页面多了再学

# 学习顺序极简总结

环境安装 → Vue3 基础语法 → Element Plus 组件 → Vue Router 路由 → Axios 请求 → 做后台页面（mock 数据）→ 对接 Django 接口 → 打包部署

你想现在直接开始： ① 先搭环境，创建第一个 Vue 项目跑起来； 还是 ② 先看基础语法，写第一个表单页面？