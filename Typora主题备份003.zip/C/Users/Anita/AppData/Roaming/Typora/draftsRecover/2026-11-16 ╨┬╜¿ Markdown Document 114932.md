

## 一、设计方案

### 1、整体架构说明

本网络采用**双核心汇聚+双出口冗余架构**，为标准企业/医院园区主流组网模型。核心层由SW1、SW3两台三层汇聚交换机组成，上行双出口路由器R1、R2，R1与R2直连构建OSPF骨干区域，实现全网三层路由冗余。

汇聚交换机之间部署**二层LACP链路聚合Trunk**，仅承担二层业务VLAN透传，不部署三层互联，规避次优路径与不对称路由，保证网络架构简洁、故障域清晰。

### 2、业务VLAN与网关规划

全网业务VLAN 10/20/30/40，采用**VRRP双机热备**实现网关冗余：

- **SW1（主网关）**：VLANIF10/20/30/40 物理地址 .201，优先级120
- **SW3（备网关）**：VLANIF10/20/30/40 物理地址 .202，默认优先级100
- **VRRP虚拟网关**：各VLAN虚拟网关统一为网段 .200

### 3、二层冗余设计（MSTP）

全网统一MST域，实现**链路负载分担+二层防环**：

- **实例1**：承载 VLAN10、VLAN20，SW1为主根、SW3为备根
- **实例2**：承载 VLAN30、VLAN40，SW3为主根、SW1为备根

通过MSTP多实例实现双上行链路负载均衡，单链路故障自动收敛，杜绝二层环路。

### 4、三层冗余设计（OSPF+VRRP+BFD）

网络采用**双层冗余机制、分层故障切换**，是企业高可用标准设计：

#### 4.1. 网关层冗余（业务优先切换）

所有业务VLAN VRRP绑定BFD会话监测上行链路连通性，当SW1上行R1链路/设备故障时，VRRP自动降优先级，SW3抢占Master网关，终端二层流量直接切换至备用核心，实现**最优路径切换**。

#### 4.2. 路由层冗余（兜底全网贯通）

R1、R2直连构建OSPF Area0骨干，双路由器动态向全网下发默认路由。若局部网关切换异常，OSPF路由自动收敛，通过对端出口设备**次优路径兜底绕行**，保障业务不中断。

#### 5、整体设计亮点（总结）

- **二层靠MSTP**：防环、负载分担、链路冗余
- **网关靠VRRP+BFD**：秒级故障感知、主备网关切换（优先保障最优路径）
- **路由靠OSPF双出口**：全网动态收敛、故障兜底绕行
- **核心间纯二层架构**：无次优路由、无不对称流量、运维简单、贴合医院/园区商用标准

**最终设计思想：优先网关最优切换，兜底路由全网容错，双层冗余保障网络高可用。**



![在这里插入图片描述](https://i-blog.csdnimg.cn/direct/bc8f5502de9f41589854098035d872be.png)

### 方案A（本片采用方案）

R1 与 R2 直接互联、作为 OSPF Area0 骨干，是园区、医院【中小型双汇聚 + 双出口】场景非常主流方案。

中小型园区、普通医院非常普遍。 工程师优先选择方案 A。 

理由： 很多项目预算、运维能力有限，追求架构简单；规避跨汇聚绕行带来的未知故障（业务系统、防火墙不对称路由坑极多）。

1. SW1 ↔ SW3：**二层 LACP 聚合 Trunk，只二层、不配置三层 Vlanif，不建立 OSPF 邻居**
2. Area0 骨干：**R1 ↔ R2 互联链路**
3. SW1 仅和 R1 建立 OSPF 邻居；SW3 仅和 R2 建立 OSPF 邻居
4. 故障依靠：**VRRP 切换网关**，禁止流量跨汇聚次优绕行

✅ 适用场景： 绝大多数制造业园区、普通二甲 / 三乙医院办公网、门诊内网； 优点： 架构干净、路由无次优路径、故障点清晰、排障简单； 设计理念：**上行故障，终端直接切换网关，不从 SW1 绕道 SW3**。

⚠️短板： 一旦 VRRP 失效没切换，直接产生流量黑洞，没有兜底绕行路径。



### 方案B

Area0 骨干放在**汇聚交换机之间**

**大型园区、三甲医院核心业务网** 很多方案会把 OSPF 骨干放在两台汇聚交换机之间，出口路由器不再互相拉线。

1. SW1 ↔ SW3：二层 Trunk 承载业务 VLAN + 新增独立三层互联 VLAN，建立 OSPF 邻居（Area0）
2. R1、R2 可以互联，也可以不互联
3. 双重冗余：VRRP 切换优先；VRRP 异常时，OSPF 支持跨汇聚绕行兜底

✅适用：三甲医院 HIS/PACS 核心业务、大型产业园； 缺点：复杂度上升，需要管控次优路径、防止不对称路由。



> 重点区分行业现实： 
>
> - 普通医院**办公外网、访客网、普通设备网**大量采用方案 A； 
>
> - 承载 HIS、监护、手术设备的**医疗核心内网**，很多设计院会倾向方案 B 做双重兜底。



### 其他

还有第三种更常见形态（很多医院现在在用） 出口不用两台独立路由器，改用**两台防火墙双机热备（VRRP / 集群）**，内网双核心交换机上联两台防火墙，防火墙之间不用单独拉线。

## 二、链路聚合

```bash
[sw1]int Eth-Trunk 1
[sw1-Eth-Trunk1]mode lacp-static
[sw1-Eth-Trunk1]trunkport g0/0/4
Info: This operation may take a few seconds. Please wait for a moment...done.
[sw1-Eth-Trunk1]trunkport g0/0/5
Info: This operation may take a few seconds. Please wait for a moment...done.
[sw1-Eth-Trunk1]port link-type trunk 
[sw1-Eth-Trunk1]port trunk allow-pass vlan 10 20 30 40

[sw3]int Eth-Trunk 1
[sw3-Eth-Trunk1]mode lacp-static
[sw3-Eth-Trunk1]trunkport g0/0/4
Info: This operation may take a few seconds. Please wait for a moment...done.
[sw3-Eth-Trunk1]trunkport g0/0/5
Info: This operation may take a few seconds. Please wait for a moment...done.
[sw3-Eth-Trunk1]port link-type trunk 
[sw3-Eth-Trunk1]port trunk allow-pass vlan 10 20 30 40


<sw3>dis eth-trunk 
Eth-Trunk1's state information is:
Local:
LAG ID: 1                   WorkingMode: STATIC                               
Preempt Delay: Disabled     Hash arithmetic: According to SIP-XOR-DIP         
System Priority: 32768      System ID: 4c1f-ccf7-0cda                         
Least Active-linknumber: 1  Max Active-linknumber: 8                          
Operate status: up          Number Of Up Port In Trunk: 2                     
--------------------------------------------------------------------------------
ActorPortName          Status   PortType PortPri PortNo PortKey PortState Weight
GigabitEthernet0/0/4   Selected 1GE      32768   5      305     10111100  1     
GigabitEthernet0/0/5   Selected 1GE      32768   6      305     10111100  1     

Partner:
--------------------------------------------------------------------------------
ActorPortName          SysPri   SystemID        PortPri PortNo PortKey PortState
GigabitEthernet0/0/4   32768    4c1f-cc59-1c3a  32768   5      305     10111100
GigabitEthernet0/0/5   32768    4c1f-cc59-1c3a  32768   6      305     10111100
```



## 三、MSTP

> 注意：只要参与 MSTP，必须和 SW1,SW2,SW3,SW4 MST域参数完全一致，否则属于不同 MST 域，环路计算异常，端口乱阻塞！后续实验各种诡异故障.
>

SW1234全部一致，都需要配置

```bash
stp region-configuration
 region-name pokes
 revision-level 1
 instance 1 vlan 10 20
 instance 2 vlan 30 40
 active region-configuration
```

调整根桥

```bash
SW1
stp instance 1 root primary 	 #将SW1作为实例1的根桥
stp instance 2 root secondary    #将SW1作为实例2的备份根桥

SW3
stp instance 1 root secondary
stp instance 2 root primary
```

查看

```bash
<sw3>dis stp brief 
 MSTID  Port                        Role  STP State     Protection
   0    GigabitEthernet0/0/1        DESI  FORWARDING      NONE
   0    GigabitEthernet0/0/2        DESI  FORWARDING      NONE
   0    GigabitEthernet0/0/3        ALTE  DISCARDING      NONE
   0    Eth-Trunk1                  ROOT  FORWARDING      NONE
   1    GigabitEthernet0/0/3        ALTE  DISCARDING      NONE
   1    Eth-Trunk1                  ROOT  FORWARDING      NONE
   2    GigabitEthernet0/0/1        DESI  FORWARDING      NONE
   2    Eth-Trunk1                  DESI  FORWARDING      NONE
```

## 三、VRRP配置

```bash

sw1

interface Vlanif10
 ip address 192.168.10.201 255.255.255.0
 vrrp vrid 10 virtual-ip 192.168.10.200
 vrrp vrid 10 priority 120

#
interface Vlanif20
 ip address 192.168.20.201 255.255.255.0
 vrrp vrid 20 virtual-ip 192.168.20.200
 vrrp vrid 20 priority 120

#
interface Vlanif30
 ip address 192.168.30.201 255.255.255.0
 vrrp vrid 30 virtual-ip 192.168.30.200
#
interface Vlanif40
 ip address 192.168.40.201 255.255.255.0
 vrrp vrid 40 virtual-ip 192.168.40.200
 
 
 sw2
 
interface Vlanif10
 ip address 192.168.10.202 255.255.255.0
 vrrp vrid 10 virtual-ip 192.168.10.200
#
interface Vlanif20
 ip address 192.168.20.202 255.255.255.0
 vrrp vrid 20 virtual-ip 192.168.20.200
#
interface Vlanif30
 ip address 192.168.30.202 255.255.255.0
 vrrp vrid 30 virtual-ip 192.168.30.200
 vrrp vrid 30 priority 120
#
interface Vlanif40
 ip address 192.168.40.202 255.255.255.0
 vrrp vrid 40 virtual-ip 192.168.40.200
 vrrp vrid 40 priority 120
```



## 四、OSPF配置

```bash
r1
ospf 1 router-id 1.1.1.1 
 default-route-advertise
 area 0.0.0.0 
  network 10.10.30.0 0.0.0.7 
  network 30.30.30.0 0.0.0.7 
  
r2
ospf 1 router-id 2.2.2.2 
 default-route-advertise
 area 0.0.0.0 
  network 30.30.30.0 0.0.0.7 
  network 40.40.30.0 0.0.0.7

sw1
ospf 1 router-id 3.3.3.3
 default-route-advertise
 area 0.0.0.0
  network 10.10.30.0 0.0.0.7
 area 0.0.0.1
  network 192.168.10.0 0.0.0.255
  network 192.168.20.0 0.0.0.255
  network 192.168.30.0 0.0.0.255
  network 192.168.40.0 0.0.0.255
  
sw3
ospf 1 router-id 4.4.4.4
 area 0.0.0.0
  network 40.40.30.0 0.0.0.7
 area 0.0.0.2
  network 192.168.30.0 0.0.0.255
  network 192.168.40.0 0.0.0.255
  network 192.168.10.0 0.0.0.255
  network 192.168.20.0 0.0.0.255
```



> 注意事项：
>
> - 不要把AR1,AR2的外网端口宣告到OSPF
> - AR1>SW1>SW2与AR2>SW3>SW4之间必须链接一条链路来承载OSPF，否则无法切换热备。因为在sw1>sw3之间是链路聚合没有IP来承载OSPF



## 五、NAT配置

```bash
r1
acl number 2000  
 rule 5 permit

interface GigabitEthernet0/0/2
 ip address 14.1.1.2 255.255.255.0 
 nat outbound 2000
 
r2
acl number 2000  
 rule 5 permit

interface GigabitEthernet0/0/2
 ip address 24.1.1.2 255.255.255.0 
 nat outbound 2000
```



## 六、默认路由

```bash
r1

ip route-static 0.0.0.0 0.0.0.0 14.1.1.1

ospf 1 router-id 1.1.1.1 
 default-route-advertise  向 OSPF 域内发布一条默认路由（0.0.0.0/0）
 
r2
ospf 1 router-id 2.2.2.2 
 default-route-advertise  向 OSPF 域内发布一条默认路由（0.0.0.0/0）
 ip route-static 0.0.0.0 0.0.0.0 24.1.1.1
```



> 踩坑：
>
> - 模拟生产高可用：删除汇聚静态默认路由，R1/R2 配置 `default-route-advertise`（不加 always）；
>   ⚠️禁止 `default-route-advertise always`，外网中断后依旧推送无效默认路由产生黑洞。
>
> - 在内网核心交换机配置浮动路由（极其不推荐！踩坑极多）外网断了，但是R1和核心之间OSPF互联接口UP,R1依旧在内网OSPF域，继续向外发布默认路由 → 核心路由表里 OSPF 默认路由还存在，浮动静态永远不会上浮！浮动路由无法感知远端外网故障，只能依靠对端OSPF路由消失才切换。
>
> - eNSP不要直接拖拽删除线缆做故障测试,极易出现端口状态缓存异常；优先使用 `shutdown` 接口模拟故障。

## 七、BFD配置

```bash
开启bfd
[r1]bfd  
[r2-bfd]q

R1
bfd pokes01 bind peer-ip 10.10.30.2 source-ip 10.10.30.1 auto

SW1
bfd pokes01 bind peer-ip 10.10.30.1 source-ip 10.10.30.2 auto

挂在接口上
interface Vlanif10
 vrrp vrid 10 track bfd-session session-name pokes01 reduced 40

interface Vlanif20
 vrrp vrid 20 track bfd-session session-name pokes01 reduced 40
```





```bash
R2
开启bfd
[r2]bfd
[r2-bfd]q

[r2]bfd pokes02 bind peer-ip 40.40.30.2 source-ip 40.40.30.1 auto

sw3
[sw3]bfd
[sw3-bfd]q
[sw3]bfd pokes02 bind peer-ip 40.40.30.1 source-ip 40.40.30.2 auto


interface Vlanif30
 vrrp vrid 30 track bfd-session session-name pokes02 reduced 40
 
 interface Vlanif40
 vrrp vrid 40 track bfd-session session-name pokes02 reduced 40
```

> SW3 上：
>
> - SW3配置完30，40之后，不需要再vrid10、vrid20 写任何 track；
> - bfd必须Up状态才生效，没有Up有可能另一端没有配置，bfd是成对出现；
> - bfd起名，整个网络内，必须唯一；
> - bfd忘记名字，可以使用：dis bfd configuration all 查看

bfd的查询

```bash
[sw3]dis bfd session all
--------------------------------------------------------------------------------
Local Remote     PeerIpAddr      State     Type        InterfaceName            
--------------------------------------------------------------------------------

8193  8192       40.40.30.1      Up        S_AUTO_PEER       -                  
--------------------------------------------------------------------------------
     Total UP/DOWN Session Number : 1/0
```

忘记名字如下查询

```bash
[sw3]dis bfd configuration all 
--------------------------------------------------------------------------------
CFG Name        CFG Type       LocalDiscr MIndex    SessNum  Commit   AdminDown 
--------------------------------------------------------------------------------

pokes02         S_AUTO_PEER    8193       257       1        True     False     
--------------------------------------------------------------------------------
     Total Commit/Uncommit CFG Number : 1/0
```